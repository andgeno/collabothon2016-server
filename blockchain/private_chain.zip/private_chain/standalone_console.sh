#!/bin/bash -e

NETWORKID=123
DATADIR=~/.private-chain-data-$NETWORKID

mkdir -p $DATADIR
cp ./static-nodes.json $DATADIR
./geth --datadir $DATADIR init ./genesis-block.json
./geth --datadir $DATADIR --vmodule=downloader=6 --nat none --networkid $NETWORKID --bootnodes leave-me-alone --rpc --rpcaddr 0.0.0.0 --rpccorsdomain '*' --etherbase 0x0000000000000000000000000000000000000000 console
